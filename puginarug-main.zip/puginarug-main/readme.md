# Pug in a Rug
A "Useless Website" revolving around a cute pic I found on unsplashed.

- You can watch me code it here https://www.youtube.com/watch?v=Sj1vbbRA07g
- Hosted @ https://puginarug.com/

Like useless sites? Support me on GitHub https://github.com/sponsors/tholman/ for more
